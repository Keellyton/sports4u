package com.sports4u;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sports4uApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sports4uApplication.class, args);
	}

}
