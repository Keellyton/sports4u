package com.sports4u;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sports4uApplicationTests {

	@Test
	void contextLoads() {
	}

}
